from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any

from nexus_core.model_router import ModelRouter
from nexus_core.models.model_registry import model_status
from nexus_core.models.ollama_client import OllamaClient
from nexus_core.organization.config import load_org_config
from nexus_core.organization.health import build_health_report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="nexus")
    sub = parser.add_subparsers(dest="command", required=True)

    setup = sub.add_parser("setup")
    setup.add_argument(
        "--apply",
        action="store_true",
        help="write system config when not running as root",
    )
    sub.add_parser("status")
    sub.add_parser("health")
    sub.add_parser("doctor")
    sub.add_parser("config")
    sub.add_parser("uninstall")

    logs = sub.add_parser("logs")
    logs.add_argument("--follow", action="store_true")
    logs.add_argument("--lines", type=int, default=80)

    model = sub.add_parser("model")
    model_sub = model.add_subparsers(dest="model_command", required=True)
    model_sub.add_parser("status")
    model_sub.add_parser("list-local")
    model_sub.add_parser("test-local")
    model_sub.add_parser("test-cloud")
    set_local = model_sub.add_parser("set-local")
    set_local.add_argument("model")
    set_cloud = model_sub.add_parser("set-cloud")
    set_cloud.add_argument("model")

    router = sub.add_parser("router")
    router_sub = router.add_subparsers(dest="router_command", required=True)
    explain = router_sub.add_parser("explain")
    explain.add_argument("task", nargs="+")

    ask = sub.add_parser("ask")
    ask.add_argument("question", nargs="+")
    run = sub.add_parser("run")
    run.add_argument("task", nargs="+")

    agents = sub.add_parser("agents")
    agents_sub = agents.add_subparsers(dest="agents_command", required=True)
    agents_sub.add_parser("status")
    restart = agents_sub.add_parser("restart")
    restart.add_argument("agent")

    args = parser.parse_args(argv)
    if args.command == "setup":
        return _print(setup_payload(apply=args.apply or os.geteuid() == 0))
    if args.command == "status":
        return _print(status_payload())
    if args.command in {"health", "doctor"}:
        return _print(health_payload())
    if args.command == "config":
        return _print(config_payload())
    if args.command == "uninstall":
        return _print(uninstall_payload())
    if args.command == "logs":
        return _logs(follow=args.follow, lines=args.lines)
    if args.command == "model":
        return _model(args)
    if args.command == "router":
        return _print(ModelRouter().classify(" ".join(args.task)).to_dict())
    if args.command == "ask":
        return _ask(" ".join(args.question))
    if args.command == "run":
        return _print(
            {
                "ok": False,
                "message": "Use 'nexus org propose-command' para execução real com aprovação. O roteamento abaixo não executou nada.",
                "routing": ModelRouter().classify(" ".join(args.task)).to_dict(),
            }
        )
    if args.command == "agents":
        return _agents(args)
    raise SystemExit(f"unknown command: {args.command}")


def setup_payload(*, apply: bool) -> dict[str, Any]:
    targets = {
        "config_dir": Path("/etc/nexus"),
        "data_dir": Path("/var/lib/nexus"),
        "workspace_dir": Path("/var/lib/nexus/workspace"),
        "log_dir": Path("/var/log/nexus"),
        "config": Path("/etc/nexus/config.toml"),
        "env": Path("/etc/nexus/nexus.env"),
    }
    project_root = Path(__file__).resolve().parents[1]
    example_config = project_root / "config" / "config.example.toml"
    example_env = project_root / "config" / "nexus.env.example"

    if not apply:
        return {
            "ok": False,
            "message": "Rode com sudo ou use --apply para gravar a configuração do sistema.",
            "would_create": {key: str(value) for key, value in targets.items()},
        }

    created: list[str] = []
    for key in ("config_dir", "data_dir", "workspace_dir", "log_dir"):
        targets[key].mkdir(parents=True, exist_ok=True)
        created.append(str(targets[key]))

    if not targets["config"].exists():
        shutil.copyfile(example_config, targets["config"])
        created.append(str(targets["config"]))
    if not targets["env"].exists():
        shutil.copyfile(example_env, targets["env"])
        created.append(str(targets["env"]))

    return {
        "ok": True,
        "message": "Configuração base do NEXUS preparada. Edite /etc/nexus/nexus.env para adicionar secrets.",
        "created_or_verified": created,
        "next": [
            "nexus health",
            "systemctl enable --now nexus",
        ],
    }


def status_payload() -> dict[str, Any]:
    config = load_org_config()
    health = build_health_report(config).to_dict()
    models = model_status()
    return {
        "daemon": health,
        "models": models,
        "paths": {
            "project_root": str(config.project_root),
            "data_dir": str(config.state_dir),
            "log_dir": str(config.logs_dir),
            "config": os.getenv(
                "NEXUS_CONFIG_PATH", str(config.project_root / "configs" / "nexus.toml")
            ),
        },
        "autonomy_level": os.getenv("NEXUS_AUTONOMY_LEVEL", "GUARDED"),
    }


def config_payload() -> dict[str, Any]:
    return {
        "system_config": "/etc/nexus/config.toml",
        "system_env": "/etc/nexus/nexus.env",
        "example_config": str(
            Path(__file__).resolve().parents[1] / "config" / "config.example.toml"
        ),
        "example_env": str(
            Path(__file__).resolve().parents[1] / "config" / "nexus.env.example"
        ),
    }


def health_payload() -> dict[str, Any]:
    status = status_payload()
    local = status["models"]["local"]
    cloud = status["models"]["cloud"]
    checks = [
        {"name": "daemon", "ok": status["daemon"]["status"] in {"online", "stopped"}},
        {
            "name": "ollama_binary",
            "ok": local["binary_found"],
            "detail": local.get("binary_path"),
        },
        {"name": "ollama_api", "ok": local["api_ok"], "detail": local.get("endpoint")},
        {
            "name": "ollama_model",
            "ok": bool(local["selected_model"]),
            "detail": local.get("selected_model") or local.get("suggestion"),
        },
        {
            "name": "cloud_key",
            "ok": cloud["api_key_present"],
            "detail": cloud["api_key_env"],
        },
        {
            "name": "logs_dir",
            "ok": Path(status["paths"]["log_dir"]).exists(),
            "detail": status["paths"]["log_dir"],
        },
    ]
    return {
        "ok": all(item["ok"] for item in checks if item["name"] != "cloud_key"),
        "checks": checks,
        **status,
    }


def _model(args: argparse.Namespace) -> int:
    client = OllamaClient()
    if args.model_command == "status":
        return _print(model_status())
    if args.model_command == "list-local":
        status = client.status()
        return _print(
            {
                "ready": status.ready,
                "selected_model": status.selected_model,
                "models": [model.__dict__ for model in status.models],
                "suggestion": None
                if status.selected_model
                else "Nenhum modelo local encontrado no Ollama. Rode, por exemplo: ollama pull qwen2.5:3b",
            }
        )
    if args.model_command == "test-local":
        response = client.generate("Responda apenas: NEXUS_LOCAL_OK")
        return _print(response.__dict__)
    if args.model_command == "test-cloud":
        cloud = model_status()["cloud"]
        return _print(
            {
                "ok": cloud["ready"],
                "provider": cloud["provider"],
                "model": cloud["model"],
                "message": "Cloud configurada."
                if cloud["ready"]
                else f"Defina {cloud['api_key_env']} ou OPENAI_API_KEY.",
            }
        )
    if args.model_command == "set-local":
        return _print(_env_assignment("NEXUS_LOCAL_MODEL", args.model))
    if args.model_command == "set-cloud":
        return _print(_env_assignment("NEXUS_CLOUD_MODEL", args.model))
    raise SystemExit(f"unknown model command: {args.model_command}")


def _agents(args: argparse.Namespace) -> int:
    if args.agents_command == "status":
        daemon = status_payload()["daemon"]
        return _print(
            {
                "ok": True,
                "daemon_status": daemon["status"],
                "agents_registered": daemon.get("agents", 0),
                "detail": daemon.get("detail"),
            }
        )
    if args.agents_command == "restart":
        return _print(
            {
                "ok": False,
                "message": "Reinicio individual ainda deve passar pelo daemon organizacional.",
                "agent": args.agent,
                "safe_command": f"nexus org health",
            }
        )
    raise SystemExit(f"unknown agents command: {args.agents_command}")


def _ask(question: str) -> int:
    decision = ModelRouter().classify(question)
    if decision.route == "local":
        response = OllamaClient().generate(question)
        return _print({"routing": decision.to_dict(), "response": response.__dict__})
    return _print(
        {
            "routing": decision.to_dict(),
            "ok": False,
            "message": "Tarefa roteada para cloud. Configure o provider e use o backend conversacional para execução estratégica.",
        }
    )


def _logs(*, follow: bool, lines: int) -> int:
    candidates = [
        Path("/var/log/nexus/nexus.log"),
        Path("/var/log/nexus/executor.log"),
        Path.cwd() / "nexus_server.log",
        Path.cwd() / "logs" / "nexus_organization_systemd.log",
    ]
    existing = next((path for path in candidates if path.exists()), None)
    if not existing:
        print("Nenhum log encontrado em /var/log/nexus ou no workspace atual.")
        return 1
    if follow:
        return subprocess.call(["tail", "-f", str(existing)])
    return subprocess.call(["tail", "-n", str(lines), str(existing)])


def _env_assignment(key: str, value: str) -> dict[str, Any]:
    return {
        "ok": True,
        "message": "Persistencia segura deve ser feita em /etc/nexus/nexus.env pelo setup.",
        "export": f"export {key}={value}",
    }


def uninstall_payload() -> dict[str, Any]:
    return {
        "ok": True,
        "message": "Para remover o pacote sem apagar dados: sudo apt remove nexus",
        "preserved_data": ["/var/lib/nexus", "/var/log/nexus", "/etc/nexus"],
        "purge_note": "Remova dados manualmente apenas se tiver backup e certeza operacional.",
    }


def _print(payload: object) -> int:
    print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
